"""
BU-Processor Core Module
======================

Core configuration and base classes for the BU-Processor system.
"""
