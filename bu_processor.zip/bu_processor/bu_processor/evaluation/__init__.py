"""
BU-Processor Evaluation Module
=============================

Model evaluation, performance metrics, and testing utilities.
"""
