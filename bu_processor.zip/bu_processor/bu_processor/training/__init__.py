"""
BU-Processor Training Module
===========================

Model training, fine-tuning, and dataset preparation utilities.
"""
