"""
BU-Processor API Module
======================

FastAPI-based REST API for document processing and classification.
"""
